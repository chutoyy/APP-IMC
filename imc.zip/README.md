Application IMC 3è année 

Membres du groupes

AZOR Mégane
BELLOT Julien
Campus de Valenciennes




Créer l'Application via la commande
expo init app-imc 

Démarrer l'Application
npm start 


